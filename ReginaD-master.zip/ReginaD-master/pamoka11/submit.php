<?php
echo 'Labas ' .$_POST['name'].' '.$_POST['username'].', how are you?';






