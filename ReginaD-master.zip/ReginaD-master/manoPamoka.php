<?php

for ($i = 100; $i < 100; $i += 2) {
echo $i . PHP_EOL;
}