<?php

declare(strict_types=1);

/*
1. Parašykite funkciją, kuri pašalintų paskutinį žodį iš stringo
"A car is standing in a parkinglot." --> "A car is standing in a"*/
// //1.budas
//$text = "A car is standing in a parkinglot.";
//
//function addString(string $newText): string {
//    $pattern = '/\w+\./';
//    $changes = '';
//    return preg_replace($pattern, $changes, $newText);
//}
//echo addString($text); // A car is standing in a
//
////2. budas
//function addString(string $newText): string {
//    $pattern = '/\s\w+\./'; //tarpas + bet koks zodis + tekstas
//    $changes = '';
//    $text = preg_replace($pattern, $changes, $newText);
//    return $text;
//}
//var_dump(addString( "A car is standing in a parkinglot.")); // string(22) "A car is standing in a"
////3. budas
//function replaceLastWord(string $sentence): string {
//    return preg_replace('/\w+\.$/', '', $sentence);
//}
//var_dump(replaceLastWord("A car is standing upside-down.")); // string(25) "A car is standing upside-"
//var_dump(replaceLastWord("A car is standing in a parkinglot.")); // string(23) "A car is standing in a "

/*2. Parašykite funkciją, kuri patikrintų, ar tekstas atitinka lietuviško mobilaus telefono numerio formatą
"+37062345678" - true
"+37012345678" - false
"+3706234567" - false
"+3706234567a" - false*/
// //1. budas
//$numbers = [
//    "+37062345678,
//     +37012345678,
//     +3706234567,
//     +3706234567a"
//];
//function mobilNumLt(string $number): bool {
//    $pattern = '/^(\+3706)(\d{7})$/';
//    if (preg_match($pattern, $number)) {
//        return true;
//    } else {
//        return false;
//    }
//}
//foreach ($numbers as $number) {
//    var_dump(mobilNumLt($number)); // bool(false)
//}
// // 2.budas
//function isValidLithuanianPhone(string $phone): bool
//{
//    return preg_match('/^\+3706\d{7}$/', $phone) === 1;
//}
//$phones = [
//    "+37062345678",
//    "+37012345678",
//    "+3706234567",
//    "+3706234567a",
//];
//
//foreach ($phones as $phone) {
//    echo $phone . ' - ' . (int)isValidLithuanianPhone($phone) . PHP_EOL;
//}
// // Atsakymas:+37062345678 - 1
// //+37012345678 - 0
//   //+3706234567 - 0
//   //+3706234567a - 0

//3. Patobulinkite funkciją (2). Funkcija turėtų galėti patikrinti ir tokius telefono numerius:
//"+370 623 45678"
//"+370-623-45678"
//"+370-623 45678"
//"00370 623 45678"
//Jeigu telefono numeris validus, iš funkcijos turėtų grįžti tvarkingai suformatuotas telefono numeris:
//"+370-623 45678" --> "+37062345678"

//function normalizePhone(string $phone): string
//{
//    return preg_replace('/^(\+|00)370( |-)6(\d{2})( |-)(\d{5})$/', '+3706$3$5', $phone);
//}
//$phones = [
//    "+370 623 45678",
//    "+370-623-45678",
//    "+370-623 45678",
//    "00370 623 45678",
//];
//foreach ($phones as $phone) {
//    var_dump(normalizePhone($phone));
//} //string(12) "+37062345678"; string(12) "+37062345678"; string(12) "+37062345678"; string(12) "+37062345678"

//4. Parašykite funkciją, kuri užmaskuotų dalį vartotojo duomenų. Pavardės ir gimimo metų simboliai
//turėtų būti pakeisti i simbolius 'X'.
//"John Smith, 1979 05 15" --> "John XXXXX, XXXX 05 15"
//
//function obfuscatePrivateInfo(string $info): string
//{
//    $matches = [];
//    $matched = preg_match('/^(\w+) (\w+), (\d{4}) (\d{2}) (\d{2})$/', $info, $matches);
//
//    if ($matched === 0)
//        return $info;
//
//    $lastName = $matches[2];
//    $lastNameObfuscated = str_pad('', strlen($lastName), 'X');
//
//    return "$matches[1] $lastNameObfuscated, XXXX $matches[4] $matches[5]";
//}
//var_dump(obfuscatePrivateInfo('John Smith, 1979 05 15')); // string(22) "John XXXXX, XXXX 05 15"


//5. Parašykite funkciją, kuri pravaliduotų IPv4 adresą. IPv4 adresas yra sudarytas iš 4 skaičių, kurių kiekvienas gali
//būti nuo 0 iki 255. Skaičiai atskirti taškais.
//Pvz.:
//255.255.255.255
//1.1.0.1
//*/
//function validateIpv4(string $input): bool
//{
//    $matches = [];
//    preg_match('/^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})$/', $input, $matches);
//
//    var_dump($matches);
//
//    return false;
//}
//validateIpv4('255.255.255.255');
//validateIpv4('1.1.0.1');

//Atsakymas:
/*array(5) {
    [0]=>
  string(15) "255.255.255.255"
    [1]=>
  string(3) "255"
    [2]=>
  string(3) "255"
    [3]=>
  string(3) "255"
    [4]=>
  string(3) "255"
}
array(5) {
    [0]=>
  string(7) "1.1.0.1"
    [1]=>
  string(1) "1"
    [2]=>
  string(1) "1"
    [3]=>
  string(1) "0"
    [4]=>
  string(1) "1"
}*/
// 2.
//function validateIpv4(string $input): bool
//{
//    $matches = [];
//    preg_match('/^(\d{1,3}).(\d{1,3}).(\d{1,3}).(\d{1,3})$/', $input, $matches);
//    $segments = array_slice($matches, 1);
//
//    foreach ($segments as $segment) {
//        if ((int)$segment > 255)
//            return false;
//    }
//    return true;
//}
//var_dump(validateIpv4('255.255.255.255'));
//var_dump(validateIpv4('255.108.255.255'));
//var_dump(validateIpv4('255.255.368.255'));
//var_dump(validateIpv4('1.1.0.1'));
//
//// Atsakymas:
////bool(true)
////bool(true)
////bool(false)
////bool(true)
//
